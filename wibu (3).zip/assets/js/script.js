
window.addEventListener('load', () => {
  document.querySelector('.loader')?.remove();
});

// Dark mode toggle (optional)
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('darkToggle');
  toggle?.addEventListener('click', () => {
    document.body.classList.toggle('dark');
  });
});
document.getElementById('darkToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
});

