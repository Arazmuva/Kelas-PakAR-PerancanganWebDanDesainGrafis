<?php
$host = 'localhost';
$user = 'u747399580_wibu';
$pass = 'Mubarok@12';
$dbname = 'u747399580_wibustore';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}
?>
