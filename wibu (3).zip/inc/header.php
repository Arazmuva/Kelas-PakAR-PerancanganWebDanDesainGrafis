<?php
require_once('config.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WibuStore</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css" />
</head>
<body>
<header>
  <nav class="navbar">
    <div class="logo">WibuStore</div>
    <div class="nav-center">
      <a href="<?= BASE_URL ?>index.php">Beranda</a>
      <a href="<?= BASE_URL ?>product.php">Produk</a>
      <a href="<?= BASE_URL ?>cart.php">Keranjang</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= BASE_URL ?>profil.php">Profil</a>
      <?php endif; ?>
      <a href="<?= BASE_URL ?>contact.php">Hubungi Kami</a>
    </div>
    <div class="nav-right">
      <form class="search-form" action="<?= BASE_URL ?>product.php" method="GET">
        <input type="text" name="q" placeholder="Cari produk..." />
        <button type="submit">🔍</button>
      </form>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= BASE_URL ?>logout.php">Keluar</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>login.php">Masuk</a>
        <a href="<?= BASE_URL ?>register.php">Daftar</a>
      <?php endif; ?>
      <button id="darkToggle" onclick="document.body.classList.toggle('dark')">🌙</button>
    </div>
  </nav>
</header>
