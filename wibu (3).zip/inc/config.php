<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

define('APP_RUNNING', true);

$baseUrl = dirname($_SERVER['SCRIPT_NAME']);
$baseUrl = rtrim($baseUrl, '/\\') . '/';
define('BASE_URL', $baseUrl);

date_default_timezone_set('Asia/Jakarta');

ini_set('display_errors', 1);
error_reporting(E_ALL);

$host     = 'localhost';
$username = 'u747399580_wibu';
$password = 'Mubarok@12';
$database = 'u747399580_wibustore';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
  die("Koneksi database gagal: " . $conn->connect_error);
}

function sanitize($data) {
  return htmlspecialchars(strip_tags(trim($data)));
}

function redirect($url) {
  header("Location: " . $url);
  exit;
}
