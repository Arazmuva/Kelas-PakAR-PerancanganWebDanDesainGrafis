<?php
$products = [];
$animes = ["naruto", "onepiece", "jujutsukaisen", "dragonball", "sololeveling"];
$counter = 1;

foreach ($animes as $anime) {
  for ($i = 1; $i <= 5; $i++) {
    $products[$counter] = [
      "id" => $counter,
      "name" => "Kaos " . ucfirst($anime) . " #$i",
      "img" => "dummy.jpg",
      "price" => 120000 + ($i * 5000),
      "anime" => $anime,
      "desc" => "Kaos premium bergambar karakter dari anime " . ucfirst($anime) . ". Bahan nyaman dan berkualitas tinggi."
    ];
    $counter++;
  }
}
?>
