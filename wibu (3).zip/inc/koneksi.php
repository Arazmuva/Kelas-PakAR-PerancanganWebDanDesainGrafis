<?php
$host = 'localhost';
$user = 'u747399580_wibu';
$pass = 'Mubarok@12';
$db   = 'u747399580_wibustore';

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
  die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
