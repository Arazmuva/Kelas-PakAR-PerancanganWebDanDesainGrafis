<?php
if (!defined('APP_RUNNING')) {
  exit('No direct script access allowed');
}
?>
<footer>
  <div class="footer-container">
    <p>© <?= date('Y') ?> WibuStore. All rights reserved.</p>
  </div>
</footer>
